"""
Módulo Interactivo de Renovación de Sesión de LinkedIn (Plan B)
Lanza una ventana física visible de Brave Browser en el escritorio del usuario (WinSta0\\Default)
utilizando schtasks /IT para resolver captchas, 2FA o introducir contraseñas actualizadas.
"""

import os
import sys
import json
import time
import uuid
import subprocess
from pathlib import Path
from playwright.async_api import async_playwright

sys.stdout.reconfigure(encoding='utf-8')

USER_PROFILE = os.environ.get("USERPROFILE", os.path.expanduser("~"))

def resolve_auth_paths():
    """Resuelve dinámicamente las rutas de credenciales y cookies de sesión."""
    env_creds = os.environ.get("LINKEDIN_CREDS_FILE")
    env_storage = os.environ.get("LINKEDIN_STORAGE_STATE_FILE")
    env_auth_dir = os.environ.get("LINKEDIN_AUTH_DIR")

    if env_creds and env_storage:
        return Path(env_creds), Path(env_storage)

    if env_auth_dir:
        auth_dir = Path(env_auth_dir)
        return auth_dir / "linkedin_creds.json", auth_dir / "linkedin_storage_state.json"

    candidates = [
        Path(USER_PROFILE) / ".gemini" / "config" / "mcp-auth",
        Path(USER_PROFILE) / ".config" / "mcp-linkedin",
        Path(__file__).parent.resolve() / "config",
        Path(__file__).parent.resolve()
    ]
    for c in candidates:
        if (c / "linkedin_creds.json").exists() or (c / "linkedin_storage_state.json").exists():
            return c / "linkedin_creds.json", c / "linkedin_storage_state.json"

    default_dir = Path(USER_PROFILE) / ".gemini" / "config" / "mcp-auth"
    if default_dir.exists():
        return default_dir / "linkedin_creds.json", default_dir / "linkedin_storage_state.json"

    std_dir = Path(USER_PROFILE) / ".config" / "mcp-linkedin"
    std_dir.mkdir(parents=True, exist_ok=True)
    return std_dir / "linkedin_creds.json", std_dir / "linkedin_storage_state.json"

CREDS_FILE, STORAGE_STATE_FILE = resolve_auth_paths()
AUTH_DIR = CREDS_FILE.parent

def resolve_temp_dir():
    env_temp = os.environ.get("LINKEDIN_TEMP_DIR")
    if env_temp:
        p = Path(env_temp)
        p.mkdir(parents=True, exist_ok=True)
        return p
    gemini_temp = Path(USER_PROFILE) / ".gemini" / "config" / "temp_interactive"
    if gemini_temp.parent.exists():
        gemini_temp.mkdir(parents=True, exist_ok=True)
        return gemini_temp
    import tempfile
    t = Path(tempfile.gettempdir()) / "mcp_linkedin_temp"
    t.mkdir(parents=True, exist_ok=True)
    return t

TEMP_DIR = resolve_temp_dir()

def get_brave_path() -> str:
    candidates = [
        os.path.expandvars(r"%LOCALAPPDATA%\BraveSoftware\Brave-Browser\Application\brave.exe"),
        os.path.expandvars(r"%PROGRAMFILES%\BraveSoftware\Brave-Browser\Application\brave.exe"),
        os.path.expandvars(r"%PROGRAMFILES(X86)%\BraveSoftware\Brave-Browser\Application\brave.exe"),
    ]
    for p in candidates:
        if os.path.exists(p):
            return p
    return candidates[0]

BRAVE_PATH = get_brave_path()

def sanitize_cookies(cookies: list) -> list:
    """Asegura que los cookies cumplan con el esquema estricto de Playwright y evita HTTP 999."""
    cleaned = []
    li_at_seen = False
    for c in cookies:
        exp = c.get("expires")
        if exp is None or not isinstance(exp, (int, float)):
            exp = -1.0
        else:
            exp = float(exp)
            
        ss = c.get("same_site") or c.get("sameSite") or "Lax"
        ss_norm = ss.capitalize() if isinstance(ss, str) else "Lax"
        if ss_norm not in ["Strict", "Lax", "None"]:
            ss_norm = "Lax"
            
        # Deduplicar li_at para evitar HTTP 999 en LinkedIn
        if c.get("name") == "li_at":
            if li_at_seen:
                continue
            li_at_seen = True
            c["domain"] = ".www.linkedin.com"
            
        cleaned.append({
            "name": c["name"],
            "value": c["value"],
            "domain": c["domain"],
            "path": c.get("path", "/"),
            "expires": exp,
            "httpOnly": c.get("httpOnly", c.get("http_only", False)),
            "secure": c.get("secure", False),
            "sameSite": ss_norm
        })
    return cleaned

async def run_visible_login(result_file: str, timeout_sec: int = 180):
    """
    Ejecuta el navegador Brave en modo visible para que el usuario resuelva cualquier
    desafío de seguridad (reCAPTCHA, 2FA, credenciales caducadas).
    """
    creds = {}
    if CREDS_FILE.exists():
        try:
            with open(CREDS_FILE, "r", encoding="utf-8") as f:
                creds = json.load(f)
        except Exception:
            pass

    async with async_playwright() as p:
        launch_kwargs = {
            "headless": False,
            "args": [
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-blink-features=AutomationControlled",
                "--new-window"
            ]
        }
        if os.path.exists(BRAVE_PATH):
            launch_kwargs["executable_path"] = BRAVE_PATH

        browser = await p.chromium.launch(**launch_kwargs)
        context = await browser.new_context(
            viewport={"width": 1280, "height": 900},
            locale="es-ES",
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
        )
        page = await context.new_page()

        try:
            # 1. Navegar a LinkedIn login en segundo plano sin robar el foco del usuario
            print("[Plan B] Abriendo ventana de login en segundo plano (sin robar foco)...")
            await page.goto("https://www.linkedin.com/login", wait_until="domcontentloaded")
            await page.wait_for_timeout(2000)

            # Aceptar cookies si aparece banner
            try:
                cookie_btn = page.get_by_role("button", name="Aceptar")
                if await cookie_btn.count() > 0:
                    await cookie_btn.first.click()
                    await page.wait_for_timeout(1000)
            except Exception:
                pass

            # 2. Si hay credenciales, rellenar de forma asistida para el usuario
            email_filled = False
            if creds.get("email"):
                try:
                    email_el = page.locator('input[type="email"]:visible, input[autocomplete*="username"]:visible, input#username, #username').first
                    await email_el.wait_for(state="visible", timeout=8000)
                    await email_el.click()
                    await email_el.fill(creds["email"])
                    email_filled = True
                    await page.wait_for_timeout(400)
                except Exception as e_err:
                    print(f"[Plan B] No se pudo autocompletar email: {e_err}")

            pass_filled = False
            if creds.get("password"):
                try:
                    pass_el = page.locator('input[type="password"]:visible, input[autocomplete*="password"]:visible, input#password, #password').first
                    await pass_el.wait_for(state="visible", timeout=8000)
                    await pass_el.click()
                    await pass_el.fill(creds["password"])
                    pass_filled = True
                    await page.wait_for_timeout(400)
                except Exception as p_err:
                    print(f"[Plan B] No se pudo autocompletar contraseña: {p_err}")

            # Solo enviar automáticamente si ambos campos se rellenaron con éxito
            if email_filled and pass_filled:
                try:
                    pass_el = page.locator('input[type="password"]:visible, input[autocomplete*="password"]:visible, input#password, #password').first
                    await pass_el.press("Enter")
                except Exception:
                    pass

            # 3. Esperar a que el usuario complete el inicio de sesión / captcha en pantalla
            print(f"[Plan B] Esperando que el usuario complete la sesión en pantalla (hasta {timeout_sec}s)...")
            start_t = time.time()
            success = False
            while time.time() - start_t < timeout_sec:
                try:
                    await page.wait_for_timeout(1500)
                    curr_url = page.url
                    if ("feed" in curr_url or "/in/" in curr_url) and "login" not in curr_url and "checkpoint" not in curr_url and "uas" not in curr_url:
                        print(f"[Plan B] ¡Sesión alcanzada exitosamente en {curr_url}!")
                        success = True
                        break
                except Exception as loop_e:
                    print(f"[Plan B] Error en espera interactiva: {loop_e}")
                    break

            if success:
                # 4. Guardar storage state depurado
                raw_state = await context.storage_state()
                raw_state["cookies"] = sanitize_cookies(raw_state.get("cookies", []))
                with open(STORAGE_STATE_FILE, "w", encoding="utf-8") as f:
                    json.dump(raw_state, f, indent=2)

                with open(result_file, "w", encoding="utf-8") as f:
                    json.dump({"status": "success", "url": page.url}, f)
                print("[Plan B] Estado de sesión y cookies guardadas con éxito.")
            else:
                with open(result_file, "w", encoding="utf-8") as f:
                    json.dump({"status": "timeout", "url": page.url}, f)
                print("[Plan B] Tiempo de espera agotado sin alcanzar el feed.")

        except Exception as e:
            print(f"[Plan B] Excepción durante login interactivo: {e}")
            try:
                with open(result_file, "w", encoding="utf-8") as f:
                    json.dump({"status": "error", "error": str(e)}, f)
            except Exception:
                pass
        finally:
            try:
                await browser.close()
            except Exception:
                pass

def trigger_interactive_session_renewal(timeout_sec: int = 180) -> bool:
    """
    Despliega la ventana visible de Brave en la sesión interactiva del usuario (WinSta0\\Default)
    mediante el Programador de Tareas Interactivo de Windows (/IT).
    """
    session_id = uuid.uuid4().hex[:8]
    task_name = f"Antigravity_LinkedIn_Renew_{session_id}"
    bat_path = TEMP_DIR / f"renew_{session_id}.bat"
    result_path = TEMP_DIR / f"result_{session_id}.json"
    log_path = TEMP_DIR / f"renew_{session_id}.log"
    script_path = Path(__file__).resolve()

    python_exe = sys.executable

    # Script batch con ejecución directa de Python
    bat_content = (
        f'@echo off\r\n'
        f'chcp 65001 >nul\r\n'
        f'"{python_exe}" "{script_path}" --worker "{result_path}" --timeout {timeout_sec} > "{log_path}" 2>&1\r\n'
    )
    with open(bat_path, "wb") as f:
        f.write(bat_content.encode("utf-8"))

    try:
        # 1. Crear tarea interactiva (/IT) en el escritorio del usuario
        c_cmd = f'& schtasks /create /tn "{task_name}" /tr "\'{bat_path}\'" /sc ONCE /st 23:59 /it /f'
        subprocess.run(["powershell", "-NoProfile", "-Command", c_cmd], capture_output=True)

        # 2. Ejecutar la tarea interactiva
        r_cmd = f'schtasks /run /tn "{task_name}"'
        subprocess.run(["powershell", "-NoProfile", "-Command", r_cmd], capture_output=True)

        # 3. Esperar el archivo de resultado
        start_wait = time.time()
        while time.time() - start_wait < timeout_sec + 10:
            if result_path.exists():
                try:
                    with open(result_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    if data.get("status") == "success":
                        # Limpiar log si fue exitoso
                        if log_path.exists():
                            try:
                                os.remove(log_path)
                            except Exception:
                                pass
                        return True
                    else:
                        return False
                except Exception:
                    pass
            time.sleep(1.0)
        return False

    finally:
        # Limpieza de la tarea programada y scripts temporales
        d_cmd = f'schtasks /delete /tn "{task_name}" /f'
        subprocess.run(["powershell", "-NoProfile", "-Command", d_cmd], capture_output=True)
        if bat_path.exists():
            try:
                os.remove(bat_path)
            except Exception:
                pass
        if result_path.exists():
            try:
                os.remove(result_path)
            except Exception:
                pass

if __name__ == "__main__":
    import asyncio
    import argparse

    parser = argparse.ArgumentParser()
    parser.add_argument("--worker", type=str, help="Ruta al archivo de resultado")
    parser.add_argument("--timeout", type=int, default=180, help="Segundos máximos de espera")
    args = parser.parse_args()

    if args.worker:
        asyncio.run(run_visible_login(args.worker, timeout_sec=args.timeout))
    else:
        print("Lanzando proceso interactivo vía schtasks /IT...")
        res = trigger_interactive_session_renewal(timeout_sec=args.timeout)
        print("Resultado de la renovación:", res)
